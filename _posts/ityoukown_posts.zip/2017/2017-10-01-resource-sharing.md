---
layout: post
title: 超过1024G的IT学习资料免费领取
no-post-nav: true
copyright: itmind
category: share
tags: [share]
---

超过1024G的IT学习资料免费领取，你值得拥有！

直接扫描二维码关注“IT轻社区”，此公号内回复对应的关键字

![](http://www.itmind.net/assets/images/itmind.jpg)  


- 01、回复"**我要健康**"，获取程序员健康、内涵大礼包！  
- 02、回复"**大数据**"，获取大数据相关资源。    
- 03、回复"**linux**"，获取linux相关资料。    
- 04、回复"**mongodb**"，获取mongodb学习资料。    
- 05、回复"**redis**"，获取redis相关资料。  
- 06、回复"**zookeeper**"，获取分布式等相关资料。   
- 07、回复"**dubbo**"，获取dubbo相关资料。    
- 08、回复"**git**"，获取git资料     
- 09、回复"**设计模式**"，获取设计模式资料  
- 10、回复"**小程序**"，获取小程序相关的资料   
- 11、回复"**android**"，获取安卓相关的资料   
- 12、回复"**java**"，获取java相关的资料  
- 13、回复"**python**"，获取Python相关资料。  
- 14、回复"**springboot**"，获取Spring Boot相关资料。  
- 15、回复"**springcloud**"，获取Spring Cloud相关资料。  


以下为超级大礼包：

- 回复 “程序员”，获取计算机专业超全教科书礼包

![](http://www.itmind.net/assets/images/2017/book/programmer.jpeg)  


- 回复“面试”，获取互联网行业私密面试大礼包

![](http://www.itmind.net/assets/images/2017/book/Interview.jpg)  

- 回复“架构师",获取十套1000G精选架构师资料

![](http://www.itmind.net/assets/images/2017/book/architect.png)  


将不定期更新资源，欢迎持续关注。  
也欢迎留言让我们知道你感兴趣的话题和资源。