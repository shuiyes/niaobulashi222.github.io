---
layout: post
title: 股票分析相关网站
category: other
tags: [other]
---

收集股票相关的一些网站

## 股票分析的网站

### 股票个维度的分析
[stockflare.com](https://stockflare.com)

### 股票新闻
[finance.yahoo.com](https://finance.yahoo.com/quote/bidu?ltr=1)

### 股票交流
[雪球](https://xueqiu.com/)

### 工具资源
[股海网](http://www.guhai.com.cn/)


### 量化分析
[股票分析（一）：常见的技术指标雪球](http://blog.callmewhy.com/2016/02/27/stock-analyse-1/)<br/>
[股票分析（二）：金叉到底灵不灵](http://blog.callmewhy.com/2016/03/06/stock-analyse-2/)<br/>
[股票分析（三）：谁与我生死与共](http://blog.callmewhy.com/2016/03/24/stock-analyse-3/)


