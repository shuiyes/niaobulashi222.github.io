---
layout:     post
title:      公众号防失联参考指南
no-post-nav: true
category: life
tags: [life]
excerpt: 初心还在。
---

我是纯洁的微笑，我还在。

![](http://www.itmind.net/assets/images/2018/life/find.jpg)

很多人给我留言说，你一个技术人就不要瞎操心别的事情了，好好搞好你的技术就行了。首先你是一个人，一个有是非观念的人，一个有独立人格的人，其次你的身份才是技术人！正是因为广大麻木不仁的民众，才会有现如今太多的不作为。

老崔的话语或许有些言辞激烈，但是大家想一下为什么会如此强烈的引发共振。说明类似的事情很普遍的发生在我们的身边，只是今天这件事情发生在了老崔身上，老崔一个人大代表也可以被这样玩弄，何况我们普通老百姓！

现在出现了一些很诡异的现象，明明你做了一个正确的事情，却人人告诉你要怎么这么着，可能你会怎么怎么样？细思极恐，这真的是21世纪，一个可以好好说话的时代吗？其实国家好多方面已经有了很大的发展，一些事情也走在了前面，但某些方面却一直在倒退!

我只是一个写代码的技术人，同时也是一个热爱祖国的中国人，希望祖国可以更加开放，让人民内心可以感到安全。不能允许类似的事情一直存在却视若无睹，言论自由是每个公民最基本的权利，争取你自己的权利，就是争取国家的权利。

如果某一天和大家失联，可以通过以下方式找到我。

1、备用公号

以后类似敏感的文章，我都会优先发送到这个公号内，以避免不必要的一些麻烦，也劳烦各位读者大人们关注。准备了一些小礼物，关注后公号内回复：1024 即可获取。

![](http://www.itmind.net/assets/images/2018/life/flyever.jpg)

2、[我的博客](http://www.ityouknow.com/)

[www.ityouknow.com](http://www.ityouknow.com/)，这个博客是我独立搭建的网站，任何时候都会存在，并且此博客只发表我自己的文章，很纯洁。

3、[我的知乎](https://www.zhihu.com/people/ityouknow/)

[https://www.zhihu.com/people/ityouknow/](https://www.zhihu.com/people/ityouknow/)，知乎也是我经常逛的一个网站，不时的会回答一些问题，在知乎专栏上面也会发布我的最新文章。

4、[我的微博](https://weibo.com/ityouknow)

[https://weibo.com/ityouknow](https://weibo.com/ityouknow)，虽然没有怎么用，但偶尔也会上去看两眼。

5、[我的 Github](https://github.com/ityouknow)

[https://github.com/ityouknow](https://github.com/ityouknow)，如果你是一个程序员，这里是我分享开源代码的地方，可以选择 Fllow 关注我的动态。

6、搜索引擎

写了多年博客稍稍有了一点影响力，你到任何搜索引擎里面输入关键字：纯洁的微笑，第一页几乎都是关于我的信息。

最后大家也可以添加我的个人微信号，不过它是个机器人，大家给它回复：加群，可以自动拉你去交流群外，其它的内容不一定可以回复你。

![](http://www.itmind.net/assets/images/2018/life/group.jpg)